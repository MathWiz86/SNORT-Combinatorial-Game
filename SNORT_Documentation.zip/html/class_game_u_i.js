var class_game_u_i =
[
    [ "AnimateBar", "class_game_u_i.html#a5f0a87a51d58d0a9ba5afed63f437e55", null ],
    [ "SetBarTextNoMoves", "class_game_u_i.html#ae27d16fa5b7f505541403d99e3d57e70", null ],
    [ "SetBarTextPlayerTurn", "class_game_u_i.html#ac025190ec608ea6aa3d342fe6373df65", null ],
    [ "SetBarTextPlayerWin", "class_game_u_i.html#ac11958c7b9bf5c72be66bd74c0a00e20", null ],
    [ "ToggleUIDisplay", "class_game_u_i.html#abb35d6a320b5eea966cafa31968cf699", null ],
    [ "barAnimator", "class_game_u_i.html#a7fe1d5eb48fc6066394bb0c7e28608c8", null ],
    [ "stateHide", "class_game_u_i.html#ae6c279abc1fe360da0756204d7e08abd", null ],
    [ "stateShow", "class_game_u_i.html#accd79ebb4954f7377ea65f105e8bdd95", null ],
    [ "tmpBar", "class_game_u_i.html#a7fb7b36f714c8d2f811305fce3666712", null ],
    [ "tmpCurrentPlayer", "class_game_u_i.html#af55169e098129885b044ba5ad51839cd", null ],
    [ "tmpInstructions", "class_game_u_i.html#a25bc6d9ff3e473aebece593a2f8be5f2", null ]
];