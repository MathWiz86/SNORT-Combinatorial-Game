var searchData=
[
  ['playerid_742',['PlayerID',['../_player_data_8cs.html#a8b808b7cd826163f2d94009361ff7aaa',1,'PlayerData.cs']]],
  ['playertype_743',['PlayerType',['../_player_data_8cs.html#abe590f3c9109f404f003d5d7e4f0fccf',1,'PlayerData.cs']]]
];
