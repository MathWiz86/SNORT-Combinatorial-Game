var searchData=
[
  ['baranimator_576',['barAnimator',['../class_game_u_i.html#a7fe1d5eb48fc6066394bb0c7e28608c8',1,'GameUI']]],
  ['bgfadespeed_577',['bgFadeSpeed',['../class_game_menu.html#a01c2c0fbb2c20acfbdaa050d00a808ad',1,'GameMenu']]],
  ['boardexpanded_578',['boardExpanded',['../class_board_size_selector_editor.html#a749abda07553574654f335af380c7e85',1,'BoardSizeSelectorEditor']]],
  ['boardsizeboundaries_579',['boardSizeBoundaries',['../class_snort_system.html#abcc7b2de62b11004818c4995e6b81bf9',1,'SnortSystem']]],
  ['buttoncolors_580',['buttonColors',['../class_menu_button.html#a20a8297bc5cdbbeb328e795a7ad4efca',1,'MenuButton']]],
  ['buttonexpanded_581',['buttonExpanded',['../class_menu_button_editor.html#a6782d6134bc127b4a6931720faf6b466',1,'MenuButtonEditor']]],
  ['buttonimage_582',['buttonImage',['../class_menu_button.html#a0a65ea60c865970d7b9ba0d20e8a3fd3',1,'MenuButton']]],
  ['buttonrtr_583',['buttonRTR',['../class_menu_button.html#a8915e14c738fb5b9dbcf3f3cf7b1397e',1,'MenuButton']]],
  ['buttontext_584',['buttonText',['../class_menu_button.html#a706416ccf532e84575a41a8e82b99e8e',1,'MenuButton']]],
  ['buttonvectors_585',['buttonVectors',['../class_menu_button.html#ac57f1dc1970f7f6943e19e19e06c139e',1,'MenuButton']]]
];
