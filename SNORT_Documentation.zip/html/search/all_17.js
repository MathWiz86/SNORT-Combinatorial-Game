var searchData=
[
  ['xaxis_378',['xAxis',['../class_board_size_selector.html#af0b273aef2ae8165b3e867b04b259936',1,'BoardSizeSelector']]]
];
