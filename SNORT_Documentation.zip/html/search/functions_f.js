var searchData=
[
  ['updateavailablecolors_571',['UpdateAvailableColors',['../class_player_setup_panel.html#ac2a94b7d60b1b4b02b01522fe3b185f5',1,'PlayerSetupPanel']]],
  ['updatepanelcolors_572',['UpdatePanelColors',['../class_menu_game_setup.html#abdac5e68d6c3dca971fb432cb272a623',1,'MenuGameSetup']]]
];
