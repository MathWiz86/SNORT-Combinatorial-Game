var searchData=
[
  ['canvas_759',['Canvas',['../class_menu.html#a4333095992063b2b5bc209c91f540400',1,'Menu']]],
  ['count_760',['Count',['../class_palette.html#afeae7e9f93688ad7bd03eaaa8d57a995',1,'Palette']]]
];
