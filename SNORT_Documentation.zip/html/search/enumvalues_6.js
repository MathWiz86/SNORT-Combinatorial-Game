var searchData=
[
  ['player1_752',['Player1',['../_player_data_8cs.html#a8b808b7cd826163f2d94009361ff7aaaaa77da55027d2fa0d53b7aa0b161daca7',1,'PlayerData.cs']]],
  ['player2_753',['Player2',['../_player_data_8cs.html#a8b808b7cd826163f2d94009361ff7aaaa35e6584330a7de7edeb92b4bf44b1aad',1,'PlayerData.cs']]]
];
