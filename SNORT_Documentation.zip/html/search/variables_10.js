var searchData=
[
  ['validspots_738',['validSpots',['../class_player_data.html#a8976cfae8b91624fc6c7b26ee5104308',1,'PlayerData']]],
  ['values_739',['values',['../class_palette.html#a2c552215353620135d7fa66b9886eb0c',1,'Palette']]]
];
