var searchData=
[
  ['previousmove_762',['PreviousMove',['../class_snort_system.html#a677a06a1fd931d464eb2ef6e2f33cf76',1,'SnortSystem']]]
];
