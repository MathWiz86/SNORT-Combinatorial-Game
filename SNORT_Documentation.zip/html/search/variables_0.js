var searchData=
[
  ['_5favailablecolors_574',['_AvailableColors',['../class_snort_system.html#a1012205a6d38a9c461be8dc2d18c274b',1,'SnortSystem']]],
  ['_5fboardsize_575',['_BoardSize',['../class_snort_system.html#a2887e068429ee0db1d70643ba19acab2',1,'SnortSystem']]]
];
