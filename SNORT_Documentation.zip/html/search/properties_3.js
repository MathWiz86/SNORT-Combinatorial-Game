var searchData=
[
  ['isreadonly_761',['IsReadOnly',['../class_palette.html#a67f58f0a4cdb9431d79b164679bbf350',1,'Palette']]]
];
