var searchData=
[
  ['animator_756',['Animator',['../class_menu.html#a85d0a09e6c673435576a51c912041017',1,'Menu']]],
  ['availablecolors_757',['AvailableColors',['../class_snort_system.html#a7491106716c5ee73399d3716c2ca75f9',1,'SnortSystem']]]
];
