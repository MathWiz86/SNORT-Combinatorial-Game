var searchData=
[
  ['togglepanel_569',['TogglePanel',['../class_exit_panel.html#a71b14214cfdfaf11d67be6c6b124d7f4',1,'ExitPanel']]],
  ['toggleuidisplay_570',['ToggleUIDisplay',['../class_game_u_i.html#abb35d6a320b5eea966cafa31968cf699',1,'GameUI']]]
];
