var class_player_setup_panel_editor =
[
    [ "Enable_PlayerSetup", "class_player_setup_panel_editor.html#a9ede0201f5afcc0b48206bcff203f4e4", null ],
    [ "Inspector_PlayerSetup", "class_player_setup_panel_editor.html#a3a70a3a056ec14511da876abf39e857b", null ],
    [ "OnEnable", "class_player_setup_panel_editor.html#aa49552e5e20af9243d777f58bae5d5b9", null ],
    [ "OnInspectorGUI", "class_player_setup_panel_editor.html#a71bbeed3077c5618a0190c4273a86a95", null ],
    [ "setupExpanded", "class_player_setup_panel_editor.html#a11375627d8d0db7f3b7b6ff9a28696fe", null ],
    [ "sp_ColorInvalidAlpha", "class_player_setup_panel_editor.html#ad2970a2130e1ac1e2c1d588937b5a70b", null ],
    [ "sp_ColorMarker", "class_player_setup_panel_editor.html#a7237c418f0e63d832d4f99b303d4ada8", null ],
    [ "sp_ColorMoveSpeed", "class_player_setup_panel_editor.html#ada8e1a58b69c01301f739db168e7768a", null ],
    [ "sp_ColorSwatches", "class_player_setup_panel_editor.html#a0b04f8e5a1ba4b748e21918a44b567f6", null ],
    [ "sp_PlayerID", "class_player_setup_panel_editor.html#a6ae3561288db0b16163ead62705b5b37", null ],
    [ "sp_SetupMenu", "class_player_setup_panel_editor.html#a71d91c034c9c9b920b85c9e62ec82167", null ]
];