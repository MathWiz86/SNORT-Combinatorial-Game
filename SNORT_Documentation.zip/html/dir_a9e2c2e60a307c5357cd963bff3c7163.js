var dir_a9e2c2e60a307c5357cd963bff3c7163 =
[
    [ "Board", "dir_3dd6efc05a8aa32bbcc68a4fed588d36.html", "dir_3dd6efc05a8aa32bbcc68a4fed588d36" ],
    [ "Camera", "dir_8a5b8c5582738ff62c39aea88484e591.html", "dir_8a5b8c5582738ff62c39aea88484e591" ],
    [ "Menu", "dir_cad31dd8f64bfa3b1443d5ba51080139.html", "dir_cad31dd8f64bfa3b1443d5ba51080139" ],
    [ "Player", "dir_4bc684cdc8014e1c2d6ace3d178b5282.html", "dir_4bc684cdc8014e1c2d6ace3d178b5282" ],
    [ "Palette.cs", "_palette_8cs.html", [
      [ "Palette", "class_palette.html", "class_palette" ],
      [ "PaletteDrawer", "class_palette_drawer.html", "class_palette_drawer" ]
    ] ]
];