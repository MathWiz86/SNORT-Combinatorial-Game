var class_player_data =
[
    [ "PlayerData", "class_player_data.html#a7dc81cafeb02f4843f6c6ec738323ad9", null ],
    [ "IsValidMove", "class_player_data.html#a4c28c04fcc7936094659ed4dcb6a56c2", null ],
    [ "IsValidMove", "class_player_data.html#adbf873f8bd355ca0148c36958ade43cd", null ],
    [ "color", "class_player_data.html#a19966abee6a1402689b96018918e3058", null ],
    [ "colorIndex", "class_player_data.html#a95fa6a44f07dfdd4fb843a0244f40d2c", null ],
    [ "invalidSpots", "class_player_data.html#a96d1802510fefb692ef169190cd659b2", null ],
    [ "type", "class_player_data.html#a68226944751f0db7e9599d272e5a1f47", null ],
    [ "validSpots", "class_player_data.html#a8976cfae8b91624fc6c7b26ee5104308", null ]
];