var _player_data_8cs =
[
    [ "PlayerData", "class_player_data.html", "class_player_data" ],
    [ "PlayerID", "_player_data_8cs.html#a8b808b7cd826163f2d94009361ff7aaa", [
      [ "Player1", "_player_data_8cs.html#a8b808b7cd826163f2d94009361ff7aaaaa77da55027d2fa0d53b7aa0b161daca7", null ],
      [ "Player2", "_player_data_8cs.html#a8b808b7cd826163f2d94009361ff7aaaa35e6584330a7de7edeb92b4bf44b1aad", null ]
    ] ],
    [ "PlayerType", "_player_data_8cs.html#abe590f3c9109f404f003d5d7e4f0fccf", [
      [ "Human", "_player_data_8cs.html#abe590f3c9109f404f003d5d7e4f0fccfac1bb19b27818343c1926119b958741b5", null ],
      [ "CPU", "_player_data_8cs.html#abe590f3c9109f404f003d5d7e4f0fccfa2b55387dd066c5bac646ac61543d152d", null ]
    ] ]
];