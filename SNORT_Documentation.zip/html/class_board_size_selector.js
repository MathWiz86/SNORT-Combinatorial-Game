var class_board_size_selector =
[
    [ "ChangeSelection", "class_board_size_selector.html#a34be27470d7896d22a4468c2a99a515a", null ],
    [ "Start", "class_board_size_selector.html#a1ea24e1779b467db82b315801807aea2", null ],
    [ "sizeFormatting", "class_board_size_selector.html#a847493c838708b04bbea37119c9640b3", null ],
    [ "xAxis", "class_board_size_selector.html#af0b273aef2ae8165b3e867b04b259936", null ]
];