var hierarchy =
[
    [ "E_Component", null, [
      [ "BoardLine", "class_board_line.html", null ],
      [ "BoardMarker", "class_board_marker.html", null ],
      [ "BoardSpot", "class_board_spot.html", null ],
      [ "ExitPanel", "class_exit_panel.html", null ],
      [ "GameMenu", "class_game_menu.html", null ],
      [ "GameUI", "class_game_u_i.html", null ],
      [ "Menu", "class_menu.html", null ],
      [ "MenuButton", "class_menu_button.html", null ],
      [ "MenuGameSetup", "class_menu_game_setup.html", null ],
      [ "ShiftSelector", "class_shift_selector.html", [
        [ "BoardSizeSelector", "class_board_size_selector.html", null ],
        [ "PlayerSetupPanel", "class_player_setup_panel.html", null ],
        [ "StartPlayerSelector", "class_start_player_selector.html", null ]
      ] ],
      [ "SnortCamera", "class_snort_camera.html", null ]
    ] ],
    [ "E_PropertyDrawer", null, [
      [ "PaletteDrawer", "class_palette_drawer.html", null ]
    ] ],
    [ "E_System", null, [
      [ "SnortSystem", "class_snort_system.html", null ]
    ] ],
    [ "EGUI_Component", null, [
      [ "BoardLineEditor", "class_board_line_editor.html", null ],
      [ "BoardMarkerEditor", "class_board_marker_editor.html", null ],
      [ "BoardSpotEditor", "class_board_spot_editor.html", null ],
      [ "GameMenuEditor", "class_game_menu_editor.html", null ],
      [ "GameUIEditor", "class_game_u_i_editor.html", null ],
      [ "MenuButtonEditor", "class_menu_button_editor.html", null ],
      [ "MenuEditor", "class_menu_editor.html", null ],
      [ "MenuGameSetupEditor", "class_menu_game_setup_editor.html", null ],
      [ "ShiftSelectorEditor", "class_shift_selector_editor.html", [
        [ "BoardSizeSelectorEditor", "class_board_size_selector_editor.html", null ],
        [ "PlayerSetupPanelEditor", "class_player_setup_panel_editor.html", null ],
        [ "StartPlayerSelectorEditor", "class_start_player_selector_editor.html", null ]
      ] ],
      [ "SnortCameraEditor", "class_snort_camera_editor.html", null ]
    ] ],
    [ "EGUI_System", null, [
      [ "SnortSystemEditor", "class_snort_system_editor.html", null ]
    ] ],
    [ "ExtensionKit", "class_extension_kit.html", null ],
    [ "IList", null, [
      [ "Palette< TEnum, TValue >", "class_palette.html", null ]
    ] ],
    [ "IPointerClickHandler", null, [
      [ "MenuButton", "class_menu_button.html", null ]
    ] ],
    [ "IPointerEnterHandler", null, [
      [ "MenuButton", "class_menu_button.html", null ]
    ] ],
    [ "IPointerExitHandler", null, [
      [ "MenuButton", "class_menu_button.html", null ]
    ] ],
    [ "KIT_Animation", "class_k_i_t___animation.html", null ],
    [ "KIT_Enum", "class_k_i_t___enum.html", null ],
    [ "Palette< PlayerID, PlayerController >", "class_palette.html", null ],
    [ "Palette< PlayerID, PlayerData >", "class_palette.html", null ],
    [ "PlayerController", "class_player_controller.html", [
      [ "CPUController", "class_c_p_u_controller.html", null ],
      [ "HumanController", "class_human_controller.html", null ]
    ] ],
    [ "PlayerData", "class_player_data.html", null ]
];