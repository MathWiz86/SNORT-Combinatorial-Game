var class_board_size_selector_editor =
[
    [ "Enable_BoardSize", "class_board_size_selector_editor.html#ab3c2ff20ec6e04866f6fb04ad313e1dd", null ],
    [ "Inspector_BoardSize", "class_board_size_selector_editor.html#a2ee609db7b084a94f65e588970889a27", null ],
    [ "OnEnable", "class_board_size_selector_editor.html#a040043d4c8ba3a8704087bc93d871763", null ],
    [ "OnInspectorGUI", "class_board_size_selector_editor.html#aada513dce92da7116d9fd7b3cacb92e7", null ],
    [ "boardExpanded", "class_board_size_selector_editor.html#a749abda07553574654f335af380c7e85", null ],
    [ "sp_XAxis", "class_board_size_selector_editor.html#ac5468e7483e993f370485f4252e4409b", null ]
];