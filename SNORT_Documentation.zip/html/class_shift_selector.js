var class_shift_selector =
[
    [ "Awake", "class_shift_selector.html#af0ff52b50ed402829a296d9f2c15da10", null ],
    [ "ChangeSelection", "class_shift_selector.html#a91f72c7df578cfffcac73c4786a913e9", null ],
    [ "MoveSelectorText", "class_shift_selector.html#ab3bc6af4f051aa6c0669d94200679853", null ],
    [ "immediateMovement", "class_shift_selector.html#ac831f64c74f5757fc95612cf0f2c4a7f", null ],
    [ "tmpTypeA", "class_shift_selector.html#af8f666dc16934ff6abd5587f0af1444b", null ],
    [ "tmpTypeB", "class_shift_selector.html#a698f8b8fe2c69f7c5fb4ddc1e4c9cef9", null ],
    [ "typeARTR", "class_shift_selector.html#a2daafc4a6b89d8e619c35be4fe35eb59", null ],
    [ "typeBRTR", "class_shift_selector.html#ad2b444f4807f176df359b921e9433349", null ],
    [ "typeMoveSpeed", "class_shift_selector.html#a934514e090a6505df4dce62689a5f58a", null ],
    [ "typePositions", "class_shift_selector.html#a31a1aa50f98ac04676093042557592ca", null ],
    [ "typeRaycastBlocker", "class_shift_selector.html#a8bc3f1791589219c31decdd0544588df", null ]
];