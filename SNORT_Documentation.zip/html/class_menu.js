var class_menu =
[
    [ "Awake", "class_menu.html#a33dc8be1e06d41483e05d20440bafb3a", null ],
    [ "Animator", "class_menu.html#a85d0a09e6c673435576a51c912041017", null ],
    [ "Canvas", "class_menu.html#a4333095992063b2b5bc209c91f540400", null ]
];