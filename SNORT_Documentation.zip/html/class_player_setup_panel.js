var class_player_setup_panel =
[
    [ "ChangePlayerColor", "class_player_setup_panel.html#ae2c67179e93eaa00df196f315e0ceb97", null ],
    [ "ChangeSelection", "class_player_setup_panel.html#a3362b80b667f82fc331b601ffe892572", null ],
    [ "InitializeColorSwatches", "class_player_setup_panel.html#a67628000eac29fc4f7751214a9a7b7e7", null ],
    [ "MoveColorMarker", "class_player_setup_panel.html#abcf15c71b22be9fcd9182c05d376e2ad", null ],
    [ "Start", "class_player_setup_panel.html#a00fa0e467939c67ac65b6d54d4e1563e", null ],
    [ "UpdateAvailableColors", "class_player_setup_panel.html#ac2a94b7d60b1b4b02b01522fe3b185f5", null ],
    [ "colorInvalidAlpha", "class_player_setup_panel.html#ad7363a4d52cb7c30b842a4524f7c3793", null ],
    [ "colorMarker", "class_player_setup_panel.html#af8f0b01872a6ac988100d5e0d3d50e80", null ],
    [ "colorMoveSpeed", "class_player_setup_panel.html#a901e5bdf2aaab9cf737d78abb66d2cfc", null ],
    [ "colorSwatches", "class_player_setup_panel.html#ab833fabd670b137d7ecc6b05dd10c8d0", null ],
    [ "markerRoutine", "class_player_setup_panel.html#af11f99a3b41dc49a476e44127286de3e", null ],
    [ "maxPlayerTypes", "class_player_setup_panel.html#a565cd2e51d7000153550f438d6c72a43", null ],
    [ "playerID", "class_player_setup_panel.html#a69337b2dc58594f12b7c0714f6f24c9b", null ],
    [ "setupMenu", "class_player_setup_panel.html#a82bdbd8da5814ba664b89b5fb71857a3", null ]
];