var class_board_spot =
[
    [ "Awake", "class_board_spot.html#adc861d55582730fef0b408e4d25f07c2", null ],
    [ "SetSpotColor", "class_board_spot.html#a8709d7be1f920ed538abacc5f0751d3d", null ],
    [ "SetSpotOpacity", "class_board_spot.html#afd4a796adcf0eb9e31620a7b74cb475c", null ],
    [ "spotIndex", "class_board_spot.html#a5bf6430dce9545662d7f8923b92dc7c4", null ],
    [ "spriteRend", "class_board_spot.html#a45ce0839ff04ff2cfa7dc552dd9571e7", null ]
];