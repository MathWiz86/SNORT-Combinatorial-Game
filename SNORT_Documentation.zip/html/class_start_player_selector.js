var class_start_player_selector =
[
    [ "ChangeSelection", "class_start_player_selector.html#adf170fc4a06cfeab02edd1653e56f53a", null ],
    [ "Start", "class_start_player_selector.html#ab7a9502a3317cd6dfe564487e0a0c0d9", null ],
    [ "maxPlayerTypes", "class_start_player_selector.html#aeb0c2e3b9f5179b82fc61fd8a080d701", null ]
];