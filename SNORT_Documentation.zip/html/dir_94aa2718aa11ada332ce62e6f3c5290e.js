var dir_94aa2718aa11ada332ce62e6f3c5290e =
[
    [ "Menu", "dir_a32e21b5d8e983bc93eb04d34677b691.html", "dir_a32e21b5d8e983bc93eb04d34677b691" ],
    [ "BoardSizeSelector.cs", "_board_size_selector_8cs.html", [
      [ "BoardSizeSelector", "class_board_size_selector.html", "class_board_size_selector" ],
      [ "BoardSizeSelectorEditor", "class_board_size_selector_editor.html", "class_board_size_selector_editor" ]
    ] ],
    [ "ExitPanel.cs", "_exit_panel_8cs.html", [
      [ "ExitPanel", "class_exit_panel.html", "class_exit_panel" ]
    ] ],
    [ "GameUI.cs", "_game_u_i_8cs.html", [
      [ "GameUI", "class_game_u_i.html", "class_game_u_i" ],
      [ "GameUIEditor", "class_game_u_i_editor.html", "class_game_u_i_editor" ]
    ] ],
    [ "MenuGameSetup.cs", "_menu_game_setup_8cs.html", [
      [ "MenuGameSetup", "class_menu_game_setup.html", "class_menu_game_setup" ],
      [ "MenuGameSetupEditor", "class_menu_game_setup_editor.html", "class_menu_game_setup_editor" ]
    ] ],
    [ "PlayerSetupPanel.cs", "_player_setup_panel_8cs.html", [
      [ "PlayerSetupPanel", "class_player_setup_panel.html", "class_player_setup_panel" ],
      [ "PlayerSetupPanelEditor", "class_player_setup_panel_editor.html", "class_player_setup_panel_editor" ]
    ] ],
    [ "ShiftSelector.cs", "_shift_selector_8cs.html", [
      [ "ShiftSelector", "class_shift_selector.html", "class_shift_selector" ],
      [ "ShiftSelectorEditor", "class_shift_selector_editor.html", "class_shift_selector_editor" ]
    ] ],
    [ "StartPlayerSelector.cs", "_start_player_selector_8cs.html", [
      [ "StartPlayerSelector", "class_start_player_selector.html", "class_start_player_selector" ],
      [ "StartPlayerSelectorEditor", "class_start_player_selector_editor.html", "class_start_player_selector_editor" ]
    ] ]
];