var class_menu_game_setup =
[
    [ "UpdatePanelColors", "class_menu_game_setup.html#abdac5e68d6c3dca971fb432cb272a623", null ],
    [ "setupPanels", "class_menu_game_setup.html#a9827ad388d9377224189b7a5ec66f62f", null ]
];