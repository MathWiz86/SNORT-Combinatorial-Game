var class_human_controller =
[
    [ "CheckBoardHover", "class_human_controller.html#afb4049c5dd051a2428eefcfa6c91d9f3", null ],
    [ "CheckBoardSpotSelect", "class_human_controller.html#a72c90526938d9100fc55222c76f874c5", null ],
    [ "HandlePlayerInput", "class_human_controller.html#ac7554ee41f730c9429de5b4742b86d5d", null ],
    [ "currentSpot", "class_human_controller.html#a40582c05e68ceebf20477d7893949041", null ]
];