var _extension_kit___image_8cs =
[
    [ "ExtensionKit", "class_extension_kit.html", "class_extension_kit" ],
    [ "ColorChannel", "_extension_kit___image_8cs.html#a3ef15c9c3e32c2ec774e3cc922443898", [
      [ "Red", "_extension_kit___image_8cs.html#a3ef15c9c3e32c2ec774e3cc922443898aee38e4d5dd68c4e440825018d549cb47", null ],
      [ "Green", "_extension_kit___image_8cs.html#a3ef15c9c3e32c2ec774e3cc922443898ad382816a3cbeed082c9e216e7392eed1", null ],
      [ "Blue", "_extension_kit___image_8cs.html#a3ef15c9c3e32c2ec774e3cc922443898a9594eec95be70e7b1710f730fdda33d9", null ],
      [ "Alpha", "_extension_kit___image_8cs.html#a3ef15c9c3e32c2ec774e3cc922443898a6132295fcf5570fb8b0a944ef322a598", null ]
    ] ]
];