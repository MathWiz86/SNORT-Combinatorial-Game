var class_extension_kit =
[
    [ "SetImageColorChannel", "class_extension_kit.html#af558faab42f178f937346417f7b1b67a", null ],
    [ "SetRendererColorChannel", "class_extension_kit.html#a118e149a57e89b705e043735da90f79b", null ]
];