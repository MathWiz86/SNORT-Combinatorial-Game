var dir_3dd6efc05a8aa32bbcc68a4fed588d36 =
[
    [ "BoardLine.cs", "_board_line_8cs.html", [
      [ "BoardLine", "class_board_line.html", "class_board_line" ],
      [ "BoardLineEditor", "class_board_line_editor.html", "class_board_line_editor" ]
    ] ],
    [ "BoardMarker.cs", "_board_marker_8cs.html", [
      [ "BoardMarker", "class_board_marker.html", "class_board_marker" ],
      [ "BoardMarkerEditor", "class_board_marker_editor.html", "class_board_marker_editor" ]
    ] ],
    [ "BoardSpot.cs", "_board_spot_8cs.html", [
      [ "BoardSpot", "class_board_spot.html", "class_board_spot" ],
      [ "BoardSpotEditor", "class_board_spot_editor.html", "class_board_spot_editor" ]
    ] ]
];